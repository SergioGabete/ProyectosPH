void eint0_ISR (void) __irq;    // Generate Interrupt 
void init_eint0 (void);
