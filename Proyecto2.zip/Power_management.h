void PM_power_down (void); 
