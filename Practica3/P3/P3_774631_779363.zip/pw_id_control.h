#ifndef PW_ID_CONTROL_H
#define PW_ID_CONTROL_H
#include <LPC210X.H>  

void idle_procesador(void);
void powerdown_procesador(void);
extern void Switch_to_PLL(void);

#endif

