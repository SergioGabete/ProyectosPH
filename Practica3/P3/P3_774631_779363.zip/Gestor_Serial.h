#ifndef GESTOR_SERIAL_H
#define GESTOR_SERIAL_H



void gestor_serial_continuar_mensaje(void);

void gestor_serial_enviar_mensaje(char msg[]);

#endif

