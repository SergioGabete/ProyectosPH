void timer0_init(void);
unsigned int timer0_read_int_count(void);
