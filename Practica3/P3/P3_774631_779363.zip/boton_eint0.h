void eint0_init (void);
unsigned int eint0_read_count(void);
void eint0_clear_nueva_pulsacion(void);
unsigned int eint0_read_count(void);
