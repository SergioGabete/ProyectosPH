#ifndef WT_H
#define WT_H

void WT_init(int segundos);

void feed_watchdog (void);

#endif

