#ifndef UART0_H
#define UART0_H

void uart0_init(void);
int uart0_sendchar(int ch) ;
int uart0_getchar(void);

#endif

