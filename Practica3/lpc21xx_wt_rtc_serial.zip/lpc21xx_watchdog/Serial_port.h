void init_serial (void);
int sendchar (int ch) ;
int getchar (void);
