void RTC_init(void);
int RTC_read_time(void);
