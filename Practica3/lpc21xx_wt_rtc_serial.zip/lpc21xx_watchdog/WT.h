void WT_init(void);
void feed_watchdog (void);
